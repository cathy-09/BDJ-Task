﻿using BDJ.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BDJ.Models
{
    public class LineSearchViewModel
    {
        public string SearchString { get; set; }
        public List<Line> Lines { get; set; }
    }
}
