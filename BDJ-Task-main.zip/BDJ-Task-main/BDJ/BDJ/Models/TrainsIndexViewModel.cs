﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BDJ.Models
{
    public class TrainsIndexViewModel
    {
        public List<TrainIndexViewModel> Trains { get; set; }
    }
}
