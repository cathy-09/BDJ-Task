﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BDJ.Models
{
    public class LinesIndexViewModel
    {
        public List<LineIndexViewModel> Lines { get; set; }
    }
}
